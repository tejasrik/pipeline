package constants;

public interface IOnlineBookStoreConstants {
	public static String CONTENT_TYPE_TEXT_HTML = "text/html";
	
	
}
